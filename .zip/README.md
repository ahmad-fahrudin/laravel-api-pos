instalasi
-cp .env.example menjadi env dan setting configuration database
-php artisan key:generate
-composer install / composer update
-php artisan migrate:fresh --seed
-php artisan serve
